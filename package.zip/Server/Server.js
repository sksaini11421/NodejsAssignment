const express = require('express');
const app = express();
const dotenv = require('dotenv');
dotenv.config();

const routes = require('../Routers/Router');
const DbConfig = require('../MySqlConfig/DbFunction');

function initialization(){
    setUpDatabase();
    setUpBodyParser();
    setUpRoutes();
    setUpError404Handler();
    setUpErrorHandler();
}
initialization();

function setUpBodyParser(){
    app.use(express.urlencoded({ extended : true }));
    app.use(express.json());
}

function setUpDatabase(){
   DbConfig.connectionCheck.then((data) => {
    console.log(`Databse Connected`);
   }).catch((err) =>{
    console.log(err);
   })
}

function setUpRoutes(){
   app.use('/v1',routes);
 }

 function setUpError404Handler(){
    app.use((req,res) =>{
        res.status(404).json({
            message : 'route not found',
            status : 404,
        })
    });
  }

  function setUpErrorHandler(){
    app.use((err,req,res ) =>{
        res.status(req.errorStatus).json({
            message : err.message || "Somethig went wrong. please retry",
            status : req.errorStatus ||  500,
        })
    });
  }

module.exports = app;