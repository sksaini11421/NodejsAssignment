const userModel = require('../Models/GetAllUsersModel');
const response = require('../Helpers/Helper');



exports.getAllUsers = async (req,res, next) =>{
    try
    {
        
        const data = req.body;
        const page_no = data.page_no;
        const userData = await userModel.getAllUsers(page_no);
        
            response.successResponseWithData(res,'Users list!.',userData[0]);
    }
    catch (error)
    {
        console.log(error.message)
        response.errorMessage(res, 'Internal Server Error');
    }
}




exports.createUser = async (req,res, next) =>{
    try
    {
        const data = req.body;
        const fname = data.fname;
        const lname = data.lname;
        const password = data.password;
        const city = data.city;
        const state = data.state;
        const country = data.country;
        const userData = await userModel.insertUserData(fname,lname,password,city,state,country);
        response.successResponse(res,'Users Added Succeed!.');
    }
    catch (error)
    {
        console.log(error.message)
        response.errorMessage(res, 'Internal Server Error');
    }
}

exports.getUserDetailById = async (req,res, next) =>{
    try
    {
        const data = req.body;
        const user_id = data.id;
        const userDetails = await userModel.getUserDetailById(user_id);
        if(userDetails.length>0)
        {
            response.successResponseWithData(res,'Users  Details Fetched!',userDetails);
        }
        else
        {
            response.errorMessage(res,'No Record found!');

        }
    }
    catch (error)
    {
        console.log(error.message)
        response.errorMessage(res, 'Internal Server Error');
    }
}

exports.updateUserDetailById = async (req,res, next) =>{
    try
    {
        const data = req.body;
        const user_id = data.id;
        const fname = data.fname;
        const lname = data.lname;
        const password = data.password;
        const city = data.city;
        const state = data.state;
        const country = data.country;
        const userDetails = await userModel.updateUserDetailById(fname,lname,password,city,state,country,user_id);
        if(userDetails)
        {
            response.successResponse(res,'Users  Details Update Succesfully!');
        }
    }
    catch (error)
    {
        response.errorMessage(res, 'Internal Server Error');
    }
}
