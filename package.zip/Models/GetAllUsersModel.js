const db = require('../MySqlConfig/DataBase');
const dbFunc = require('../MySqlConfig/DbFunction');


exports.getAllUsers = async (page_no) =>{
    return new Promise((resolve, reject) =>{
        const queryString = `CALL get_all_users(?)`;
        db.query(queryString,[page_no], (error,result,fields) =>{
            if(error){
                dbFunc.connectionRelease;
                reject(error);
            }
            else
            {
                dbFunc.connectionRelease;
                resolve(result);
            }
        })
    })
}

exports.insertUserData = async (fname,lname,password,city,state,country) =>{
    return new Promise((resolve, reject) =>{
        const queryString = `INSERT INTO users(fname,lname,password,city,state,country) VALUES(?,?,?,?,?,?)`;
        db.query(queryString,[fname,lname,password,city,state,country], (error,result,fields) =>{
            if(error){
                dbFunc.connectionRelease;
                reject(error);
            }
            else
            {
                dbFunc.connectionRelease;
                resolve(result);
            }
        })
    })
}

exports.getUserDetailById = async (user_id) =>{
    return new Promise((resolve, reject) =>{
        const queryString = `SELECT * FROM users WHERE id=?`;
        db.query(queryString,[user_id], (error,result,fields) =>{
            if(error){
                dbFunc.connectionRelease;
                reject(error);
            }
            else
            {
                dbFunc.connectionRelease;
                resolve(result);
            }
        })
    })
}


exports.updateUserDetailById = async (fname,lname,password,city,state,country,user_id) =>{
    return new Promise((resolve, reject) =>{
        const queryString = `UPDATE users SET fname=?,lname=?,password=?,city=?,state=?,country=? WHERE id=?`;
        db.query(queryString,[fname,lname,password,city,state,country,user_id], (error,result,fields) =>{
            if(error){
                dbFunc.connectionRelease;
                reject(error);
            }
            else
            {
                dbFunc.connectionRelease;
                resolve(result);
            }
        })
    })
}


