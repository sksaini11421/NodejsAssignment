const app = require('./Server/Server');

app.listen(process.env.PORT,(req,res) =>{
    console.log(`server running on ${process.env.PORT}`);
})