const express = require('express');
const routes = express.Router();
module.exports  = routes;


const AllUsersListController = require('../Controllers/GetAllUsersController');

routes.get('/getAllUsers',AllUsersListController.getAllUsers);
routes.post('/createUser',AllUsersListController.createUser);
routes.get('/getUserDetails',AllUsersListController.getUserDetailById);
routes.post('/updateUser',AllUsersListController.updateUserDetailById);

