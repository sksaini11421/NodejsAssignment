
module.exports = {
    successResponseWithData: (res,msg,data) =>{
        data = {
            message : msg,
            data: data
        };
        return res.status(200).json(data);
    },
    successResponse: (res,msg) =>{
        data = {
            message : msg
        };
        return res.status(200).json(data);
    },
    errorMessage : (res,msg) =>{
        data = {
            message: msg
        };
        return res.status(400).json(data);
    }
}